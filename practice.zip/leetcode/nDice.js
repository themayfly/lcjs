/**
 * @param {number} d
 * @param {number} f
 * @param {number} target
 * @return {number}
 */
var numRollsToTarget = function(d, f, target) {
  const possibility = Math.pow(f, d);
  const list = [];
  for (const i = 0; i < d; i++) {
    for (const j = 0; j < f; j++) {

    }
  }
};