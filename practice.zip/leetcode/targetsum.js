var findTargetSumWays = functions(nums, S) {

  const signs = ['+', '-'];
  const map = {};
  nums.forEach((el, idx) => {
    for (let sign of sign) {

    }
  })

}
