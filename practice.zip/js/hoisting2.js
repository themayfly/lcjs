foo()
var foo = 2
function foo() {
  console.log(1)
}
foo = function() {
  console.log(2)
}
