function fn() {
  b = 2
  console.log('##### this.b = ', this.b)
  console.log(this)
}

fn()
