
console.log(a);

var a = 1;

console.log(a);


/////////////////////////////

f1(1);
function f1(a) { console.log(a); return a; }


