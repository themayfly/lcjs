
const digits = [
  '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
]

const MIN = '000000'
const MAX = 'ZZZZZZ' // Math.pow(62, )
const get = url => {

}
