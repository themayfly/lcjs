const remainder = (num1, num2) => {
  // boundary condition
  if (isNaN(num1) || isNaN(num2)) {
    return "one of input parameter is wrong";
  } else if (num1 === Infinity || num2 === 0) {
    return "one of input parameter is wrong";
  } else if (num1 < 0) {

  }
}