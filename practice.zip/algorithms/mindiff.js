// return 2 combinations which has mininum difference
var list = [5, 6, 11, 1];

