
const compare = (nodeA, nodeB) => {
  if (!nodeA || !nodeA) {
    return true;
  }
}
const isSymmetrical = (arr) => {

}